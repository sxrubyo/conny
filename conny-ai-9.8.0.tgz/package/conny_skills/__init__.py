"""Conny skills scaffold."""
