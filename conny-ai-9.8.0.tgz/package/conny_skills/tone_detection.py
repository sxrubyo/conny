"""Tone detection scaffold."""
