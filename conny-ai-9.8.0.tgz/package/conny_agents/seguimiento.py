"""Agente de seguimiento scaffold."""
