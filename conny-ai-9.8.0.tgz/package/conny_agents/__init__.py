"""Conny agents scaffold."""
