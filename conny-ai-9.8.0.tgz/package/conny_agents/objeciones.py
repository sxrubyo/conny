"""Agente de objeciones scaffold."""
