"""Agente de captacion scaffold."""
