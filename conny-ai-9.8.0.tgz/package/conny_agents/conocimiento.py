"""Agente de conocimiento scaffold."""
